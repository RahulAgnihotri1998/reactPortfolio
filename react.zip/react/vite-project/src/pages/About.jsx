// eslint-disable-next-line no-unused-vars
import React from "react";

const About = () => {
  return <h1>About Us</h1>;
};

export default About;
