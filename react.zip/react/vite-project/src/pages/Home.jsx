// eslint-disable-next-line no-unused-vars
import React from "react";
import Banner from "../components/Banner";
import Heading from "../components/Heading";
import Card from "../components/card"; // Import the Card component
import ResumeCard from "../components/ResumeCard"; // Import the ResumeCard component
import ContactForm from "../components/Contact"; // Import the ContactForm component

const App = () => {
  // Experience data for the "Experience" section
  const experienceData = [
    {
      image: "https://via.placeholder.com/500",
      dateRange: "2020-Present",
      title: "Software Developer",
      role: "Co-Founder",
      company: "Microsoft Corporation",
      description: "Leading a team of software developers to create innovative solutions.",
      buttonText: "Contact Me",
      onButtonClick: () => alert("Contacting Software Developer"),
    },
    {
      image: "https://via.placeholder.com/500",
      dateRange: "2015-2020",
      title: "Web Design",
      role: "Founder",
      company: "XYZ IT Company",
      description: "Reinventing the way you create websites and web applications.",
      buttonText: "Contact Me",
      onButtonClick: () => alert("Contacting Web Designer"),
    },
    {
      image: "https://via.placeholder.com/500",
      dateRange: "2018-2022",
      title: "UI/UX Designer",
      role: "Lead Designer",
      company: "Innovative Design Studio",
      description: "Focusing on user-centered design principles to deliver beautiful UI/UX.",
      buttonText: "Contact Me",
      onButtonClick: () => alert("Contacting UI/UX Designer"),
    },
    {
      image: "https://via.placeholder.com/500",
      dateRange: "2017-2019",
      title: "Frontend Developer",
      role: "Tech Solutions",
      company: "Building amazing web apps with a strong frontend focus.",
      description: "Creating dynamic and responsive websites with a focus on front-end technologies.",
      buttonText: "Contact Me",
      onButtonClick: () => alert("Contacting Frontend Developer"),
    },
    {
      image: "https://via.placeholder.com/500",
      dateRange: "2014-2017",
      title: "Web Developer",
      role: "Junior Developer",
      company: "Creative Web Solutions",
      description: "Focused on backend development and improving website functionality.",
      buttonText: "Contact Me",
      onButtonClick: () => alert("Contacting Web Developer"),
    },
  ];

  // Journey data for the "My Journey" section
  const journeyData = [
    {
      title: "BSc in Computer Science",
      dateRange: "2006 - 2010",
      description: "The training provided by universities in order to prepare people to work in various sectors of the economy or areas of culture.",
      countryFlag: "USA",
    },
    {
      title: "Sr. Software Engineer",
      dateRange: "2017 - Present",
      description: "Google's hiring process is an important part of our culture. Googlers care deeply about their teams and the people who make them up.",
      countryFlag: "USA",
    },
    {
      title: "Web Developer & Trainer",
      dateRange: "2012 - 2016",
      description: "Apple Developer Team - Building amazing apps and sharing the knowledge with the developer community.",
      countryFlag: "Malaysia",
    },
    {
      title: "AS - Science & Information",
      dateRange: "2001 - 2005",
      description: "A foundational degree focused on the basics of technology and its applications.",
      countryFlag: "UK",
    },
  ];

  return (
    <>
      {/* Banner Section */}
      <Banner />

      {/* Experience Section */}
      <div className="experience ">
        <div className="text-center">
          <Heading
            subtitle="Welcome to My Portfolio"
            title="Discover My Work"
            subtitleClassName="text-danger"
            titleClassName="text-light"
          />
        </div>

        {/* Experience Cards */}
        <div className="row justify-content-center">
          {experienceData.map((experience, index) => (
            <div className="col-md-8 mb-4" key={index}>
              <Card
                image={experience.image}
                dateRange={experience.dateRange}
                title={experience.title}
                role={experience.role}
                company={experience.company}
                description={experience.description}
                buttonText={experience.buttonText}
                onButtonClick={experience.onButtonClick}
              />
            </div>
          ))}
        </div>
      </div>

      {/* My Journey Section */}
      <div className="journey">
        <Heading
          subtitle="Explore My Journey"
          title="My Journey"
          subtitleClassName="text-danger"
          titleClassName="text-light"
        />
        <div className="timeline">
          {journeyData.map((journey, index) => (
            <ResumeCard
              key={index}
              title={journey.title}
              dateRange={journey.dateRange}
              description={journey.description}
              countryFlag={journey.countryFlag}
            />
          ))}
        </div>
      </div>

      {/* Contact Us Section */}
      <div className="contact-us ">
      <Heading
          subtitle=""
          title="Contact Us"
          subtitleClassName="text-danger"
          titleClassName="text-light"
        />
        <div className="container">
          <div className="row">
            {/* Contact About Area */}
            <div className="col-md-4">
              <div className="contact-about-area">
                <div className="thumbnail mb-4">
                  <img
                    loading="lazy"
                    decoding="async"
                    width="460"
                    height="288"
                    src="https://rainbowit.net/themes/inbio/wp-content/uploads/2021/08/contact1.png"
                    alt="Contact Thumbnail"
                    className="img-fluid"
                  />
                </div>
                <div className="title-area mb-3">
                  <h4 className="title">Nevine Acotanza</h4>
                  <span>Chief Operating Officer</span>
                </div>
                <div className="description mb-4">
                  <p>
                    I am available for freelance work. Connect with me via email or call my account.
                  </p>
                  <span className="phone d-block">
                    Phone: <a href="tel:+01234567890">+012 345 678 90</a>
                  </span>
                  <span className="mail d-block">
                    Email: <a href="mailto:admin@example.com">admin@example.com</a>
                  </span>
                </div>
                <div className="social-area">
                  <div className="name mb-2">FIND WITH ME</div>
                  <div className="social-icons d-flex gap-3">
                    <a href="#" title="Twitter" className="text-decoration-none">
                      <i className="feather-twitter"></i>
                    </a>
                    <a href="#" title="Facebook" className="text-decoration-none">
                      <i className="feather-facebook"></i>
                    </a>
                    <a href="#" title="LinkedIn" className="text-decoration-none">
                      <i className="feather-linkedin"></i>
                    </a>
                  </div>
                </div>
              </div>
            </div>

            {/* Contact Form Area */}
            <div className="col-md-8">
              <ContactForm />
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default App;
