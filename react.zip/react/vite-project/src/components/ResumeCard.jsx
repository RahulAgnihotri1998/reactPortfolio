// eslint-disable-next-line no-unused-vars
import React from 'react';
import PropTypes from 'prop-types';

const ResumeCard = ({
  title,
  dateRange,
  description,

  countryFlag,
}) => {
  return (
    <div className="resume-card my-4 p-4 border rounded bg-dark text-white shadow-lg">
      <div className="d-flex justify-content-between align-items-center">
        <div>
          {/* Title */}
          <h5 className="fw-bold">{title}</h5>

          {/* Date Range */}
          <span className="text-muted">{dateRange}</span>
        </div>

        {/* Location Badge */}
        {countryFlag && (
          <span className="badge bg-danger">{countryFlag}</span>
        )}
      </div>

      {/* Description */}
      <p className="mt-2 text-muted">{description}</p>
    </div>
  );
};

ResumeCard.propTypes = {
  title: PropTypes.string.isRequired,
  dateRange: PropTypes.string.isRequired,
  description: PropTypes.string.isRequired,
  location: PropTypes.string,
  countryFlag: PropTypes.string,
};

export default ResumeCard;
