// eslint-disable-next-line no-unused-vars
import React from 'react';


const Banner = () => {
  return (
    <section className="banner">
      <div className="banner-content">
        <div className="banner-text">

            <div className="banner-card">
          <div className="user">
            <img
              src="../public/img/icons8-user-24.png" // Replace with your actual profile image URL
              alt="Profile"
              className="userImg"
            />
          </div>
          <h1 className="greeting">Hi, I’m Rahul</h1>
          <p className="description">
            Web designer and developer working for MaidenStride in Kanpur, India.
          </p>
          <div className="contact-info">
            <p><strong>Web Designer & Developer</strong></p>
            <p><strong>Email:</strong> rahulagnihotri1998@gmail.com</p>
            <p><strong>Location:</strong> Kanpur, Uttar Pradesh, India</p>
          </div>
          </div>
          <div className="button-group">
            <a href="/cv" className="btn btn-primary">Download CV</a>
            <a href="/contact" className="btn btn-secondary">Contact Me</a>
          </div>
        </div>
        <div className="banner-image">
          <img
            src="../public/img/66dfd76243208.jpeg" // Replace with an actual image URL
            alt="Profile background"
            className="banner-bg-img"
          />
        </div>
      </div>
    </section>
  );
};

export default Banner;
