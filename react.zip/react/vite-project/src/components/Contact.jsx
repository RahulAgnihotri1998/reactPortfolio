// eslint-disable-next-line no-unused-vars
import React, { useState } from "react";

const ContactForm = () => {
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    subject: "",
    message: "",
  });

  const [errors, setErrors] = useState({});
  const [formMessage, setFormMessage] = useState("");

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
    setErrors({ ...errors, [name]: "" });
  };

  // Form validation
  const validateForm = () => {
    const newErrors = {};
    if (!formData.name) newErrors.name = "Your name is required.";
    if (!formData.phone) newErrors.phone = "Phone number is required.";
    if (!formData.email) {
      newErrors.email = "Email is required.";
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = "Invalid email format.";
    }
    if (!formData.subject) newErrors.subject = "Subject is required.";
    if (!formData.message) newErrors.message = "Message is required.";
    return newErrors;
  };

  // Handle form submission
  const handleSubmit = (e) => {
    e.preventDefault();
    const validationErrors = validateForm();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      setFormMessage("One or more fields have an error. Please check and try again.");
      return;
    }
    // Form submission logic here
    setFormMessage("Thank you for contacting us! We'll get back to you soon.");
    setFormData({
      name: "",
      phone: "",
      email: "",
      subject: "",
      message: "",
    });
  };

  return (
    <div className="contact-form-wrapper">
      <div className="introduce">
        <form className="rnt-contact-form rwt-dynamic-form row" onSubmit={handleSubmit}>
          {/* Form message */}
          {formMessage && (
            <div className={`col-lg-12 wpcf7-response-output ${errors ? "error" : "success"}`} aria-hidden="true">
              {formMessage}
            </div>
          )}

          {/* Name field */}
          <div className="col-lg-6">
            <div className="form-group">
              <p>
                <label htmlFor="contact-name">Your Name</label>
                <input
                  size="40"
                  maxLength="400"
                  className={`form-control ${errors.name ? "is-invalid" : ""}`}
                  id="contact-name"
                  value={formData.name}
                  onChange={handleChange}
                  name="name"
                  type="text"
                />
                {errors.name && <small className="text-danger">{errors.name}</small>}
              </p>
            </div>
          </div>

          {/* Phone number field */}
          <div className="col-lg-6">
            <div className="form-group">
              <p>
                <label htmlFor="contact-phone">Phone Number</label>
                <input
                  size="40"
                  maxLength="400"
                  className={`form-control ${errors.phone ? "is-invalid" : ""}`}
                  id="contact-phone"
                  value={formData.phone}
                  onChange={handleChange}
                  name="phone"
                  type="text"
                />
                {errors.phone && <small className="text-danger">{errors.phone}</small>}
              </p>
            </div>
          </div>

          {/* Email field */}
          <div className="col-lg-12">
            <div className="form-group">
              <p>
                <label htmlFor="contact-email">Email</label>
                <input
                  size="40"
                  maxLength="400"
                  className={`form-control ${errors.email ? "is-invalid" : ""}`}
                  id="contact-email"
                  value={formData.email}
                  onChange={handleChange}
                  name="email"
                  type="email"
                />
                {errors.email && <small className="text-danger">{errors.email}</small>}
              </p>
            </div>
          </div>

          {/* Subject field */}
          <div className="col-lg-12">
            <div className="form-group">
              <p>
                <label htmlFor="contact-subject">Subject</label>
                <input
                  size="40"
                  maxLength="400"
                  className={`form-control ${errors.subject ? "is-invalid" : ""}`}
                  id="contact-subject"
                  value={formData.subject}
                  onChange={handleChange}
                  name="subject"
                  type="text"
                />
                {errors.subject && <small className="text-danger">{errors.subject}</small>}
              </p>
            </div>
          </div>

          {/* Message field */}
          <div className="col-lg-12">
            <div className="form-group">
              <p>
                <label htmlFor="contact-message">Your Message</label>
                <textarea
                  cols="40"
                  rows="10"
                  maxLength="2000"
                  className={`form-control ${errors.message ? "is-invalid" : ""}`}
                  id="contact-message"
                  value={formData.message}
                  onChange={handleChange}
                  name="message"
                ></textarea>
                {errors.message && <small className="text-danger">{errors.message}</small>}
              </p>
            </div>
          </div>

          {/* Submit button */}
          <div className="col-lg-12">
            <p>
              <button className="btn btn-primary" type="submit">
                SEND MESSAGE
              </button>
            </p>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ContactForm;
