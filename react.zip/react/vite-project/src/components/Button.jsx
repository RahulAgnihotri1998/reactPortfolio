// Button.js
// eslint-disable-next-line no-unused-vars
import React from 'react';

// eslint-disable-next-line react/prop-types
export const Button = ({ text, onClick, className, disabled }) => {
  return (
    <button
      className={`btn ${className}`} // Apply dynamic classes
      onClick={onClick} // Attach the onClick handler
      disabled={disabled} // Control the disabled state
    >
      {text} {/* Render the button text */}
    </button>
  );
};
