// Navbar.js
// eslint-disable-next-line no-unused-vars
import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from './Button'; // Import the Button component

export const Navbar = () => {
  const handleHireMeClick = () => {
    alert('Hire Me button clicked!');
  };

  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div className="container-fluid">
        {/* Profile image and name */}
        <a className="navbar-brand d-flex align-items-center" href="#">
          <img
            src="https://via.placeholder.com/50" // Replace with your profile image URL
            alt="Profile"
            className="rounded-circle"
            width="40"
            height="40"
          />
          <span className="ms-2 text-white">INBIO</span>
        </a>

        {/* Hamburger menu for smaller screens */}
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
          aria-controls="navbarNav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        {/* Navigation links */}
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav ms-auto">
            <li className="nav-item">
              <Link className="nav-link active text-white" to="/">I AM</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link text-white" to="/experience">MY EXPERIENCE</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link text-white" to="/education">EDUCATION</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link text-white" to="/resume">RESUME</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link text-white" to="/portfolio">PORTFOLIO</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link text-white" to="/blog">BLOG</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link text-white" to="/contacts">CONTACTS</Link>
            </li>

             {/* Hire Me Button */}
             <li className="nav-item">
              <Button
                text="Hire Me"
                onClick={handleHireMeClick}
                className="btn-danger ms-3"
              />
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
};
