// Card.jsx
// eslint-disable-next-line no-unused-vars
import React from 'react';
import PropTypes from 'prop-types';

const Card = ({
  image,
  dateRange,
  title,
  role,
  company,
  description,
  buttonText,
  onButtonClick,
}) => {
  return (
    <div className="card  text-white mb-4 border-0">
      <div className="row g-0 align-items-center">
        {/* Image Section */}
        <div className="col-md-4 p-5">
          <img
            src={image}
            alt={title}
            className="img-fluid rounded-start"
            style={{ height: '100%', objectFit: 'cover' }}
          />
        </div>

        {/* Content Section */}
        <div className="col-md-8">
          <div className="card-body">
            {/* Date Range */}
            <span className="badge bg-secondary text-uppercase mb-2">{dateRange}</span>

            {/* Title */}
            <h5 className="card-title fw-bold">{title}</h5>

            {/* Role & Company */}
            <p className="card-text mb-1">
              <span className="text-white">{role}</span>
            </p>
            <p className="card-text">
              <span className="text-white">{company}</span>
            </p>

            {/* Description */}
            {description && <p className="text-white">{description}</p>}

            {/* Button */}
            {buttonText && (
              <button
                className="btn btn-outline-danger mt-3"
                onClick={onButtonClick}
              >
                {buttonText}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

Card.propTypes = {
  image: PropTypes.string.isRequired,
  dateRange: PropTypes.string.isRequired,
  title: PropTypes.string.isRequired,
  role: PropTypes.string.isRequired,
  company: PropTypes.string.isRequired,
  description: PropTypes.string,
  buttonText: PropTypes.string,
  onButtonClick: PropTypes.func,
};

export default Card;
