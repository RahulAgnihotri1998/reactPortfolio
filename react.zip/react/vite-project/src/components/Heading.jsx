// Heading.jsx
// eslint-disable-next-line no-unused-vars
import React from 'react';
import PropTypes from 'prop-types';

const Heading = ({
  title,
  subtitle = '', // Default value for subtitle
  subtitleClassName = 'text-secondary', // Default value for subtitle styling
  titleClassName = 'text-dark', // Default value for title styling
}) => {
  return (
    <div className="text-center mb-10">
      {subtitle && <h6 className={`text-uppercase mb-3 ${subtitleClassName}`}>{subtitle}</h6>}
      <h1 className={`display-4 fw-bold ${titleClassName}`}>{title}</h1>
    </div>
  );
};

// PropTypes for type-checking
Heading.propTypes = {
  title: PropTypes.string.isRequired,
  subtitle: PropTypes.string,
  subtitleClassName: PropTypes.string,
  titleClassName: PropTypes.string,
};

export default Heading;
